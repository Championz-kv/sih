/* =========================================================================
   CIVICSOLVE — DASHBOARD.JS
   UI-prototype only: no backend, no real authentication. The "role" is
   read from the URL (?role=submitter|solver|industry) purely so the
   dashboard can be styled/labelled per audience later — nothing here
   gates access or verifies identity.
   ========================================================================= */

document.addEventListener('DOMContentLoaded', () => {

  /* ---------------------------------------------------------------------
     1. THEME — shares the same localStorage key as the landing page,
        so arriving from a login button keeps whatever mode was active.
  --------------------------------------------------------------------- */
  const themeToggle = document.getElementById('themeToggle');
  const themeIcon = themeToggle.querySelector('i');

  const applyTheme = (dark) => {
    document.body.classList.toggle('dark', dark);
    themeIcon.className = dark ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
  };

  const savedTheme = localStorage.getItem('civicsolve-theme');
  applyTheme(savedTheme ? savedTheme === 'dark' : window.matchMedia('(prefers-color-scheme: dark)').matches);

  themeToggle.addEventListener('click', () => {
    const nowDark = !document.body.classList.contains('dark');
    applyTheme(nowDark);
    localStorage.setItem('civicsolve-theme', nowDark ? 'dark' : 'light');
  });

  /* ---------------------------------------------------------------------
     2. ROLE — read from ?role=, reflected in the header. Structured so a
        real auth layer can later replace this with the logged-in user's
        actual role instead of a URL param.
  --------------------------------------------------------------------- */
  const ROLE_LABELS = { submitter: 'Citizen', solver: 'Problem Solver', industry: 'Industry Partner' };
  const params = new URLSearchParams(window.location.search);
  let currentRole = params.get('role') || 'submitter';

  const roleLabel = document.getElementById('roleLabel');
  const roleSwitchBtn = document.getElementById('roleSwitchBtn');
  const roleSwitchMenu = document.getElementById('roleSwitchMenu');

  const setRole = (role) => {
    currentRole = ROLE_LABELS[role] ? role : 'submitter';
    roleLabel.textContent = ROLE_LABELS[currentRole];
    const url = new URL(window.location);
    url.searchParams.set('role', currentRole);
    window.history.replaceState({}, '', url);
  };
  setRole(currentRole);

  roleSwitchBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    roleSwitchMenu.classList.toggle('open');
  });
  roleSwitchMenu.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', () => {
      setRole(btn.dataset.role);
      roleSwitchMenu.classList.remove('open');
    });
  });

  /* ---------------------------------------------------------------------
     3. NOTIFICATIONS DROPDOWN
  --------------------------------------------------------------------- */
  const notifBtn = document.getElementById('notifBtn');
  const notifPanel = document.getElementById('notifPanel');
  notifBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    notifPanel.classList.toggle('open');
  });

  document.addEventListener('click', () => {
    roleSwitchMenu.classList.remove('open');
    notifPanel.classList.remove('open');
  });

  /* ---------------------------------------------------------------------
     4. MOBILE SIDEBAR TOGGLE
  --------------------------------------------------------------------- */
  const dashSidebar = document.getElementById('dashSidebar');
  const dashMenuBtn = document.getElementById('dashMenuBtn');
  dashMenuBtn.addEventListener('click', () => dashSidebar.classList.toggle('open'));

  /* ---------------------------------------------------------------------
     5. SIDEBAR ACTIVE-LINK STATE (demo only — all panels show same view)
  --------------------------------------------------------------------- */
  document.querySelectorAll('.dash-nav__link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      document.querySelectorAll('.dash-nav__link').forEach(l => l.classList.remove('active'));
      link.classList.add('active');
      dashSidebar.classList.remove('open');
    });
  });

  /* ---------------------------------------------------------------------
     6. CATEGORY CHIPS
  --------------------------------------------------------------------- */
  const categories = ['Education', 'Healthcare', 'Agriculture', 'Water & Sanitation', 'Infrastructure', 'Energy', 'Transport', 'Governance', 'Environment', 'Livelihood', 'Disaster Relief'];
  document.getElementById('chipRow').innerHTML =
    categories.slice(0, 6).map(c => `<span class="chip">${c}</span>`).join('') +
    `<span class="chip">+${categories.length - 6} more</span>`;

  /* ---------------------------------------------------------------------
     7. PROCESS TRACK
  --------------------------------------------------------------------- */
  const processSteps = ['Identify', 'Validate', 'Discover', 'Connect', 'Collaborate', 'Develop', 'Deploy', 'Measure Impact'];
  document.getElementById('processTrack').innerHTML = processSteps.map((step, i) => `
    <div class="p-step">
      <span class="p-step__num">${String(i + 1).padStart(2, '0')}</span>
      <span class="p-step__label">${step}</span>
    </div>
  `).join('');

  /* ---------------------------------------------------------------------
     8. STATISTICS (demo values, count up on load)
  --------------------------------------------------------------------- */
  const stats = [
    { label: 'Problems Filed', value: 12482, delta: '+4.2% wk' },
    { label: 'Validated', value: 8931, delta: '+2.1% wk' },
    { label: 'Active Projects', value: 1847, delta: '+6.0% wk' },
    { label: 'Resolved', value: 642, delta: '+1.3% wk' },
    { label: 'Organizations', value: 387, delta: '+12 new' },
    { label: 'Universities', value: 62, delta: 'steady', flat: true },
  ];

  const dashStats = document.getElementById('dashStats');
  dashStats.innerHTML = stats.map(s => `
    <div class="d-stat">
      <span class="d-stat__num" data-target="${s.value}">0</span>
      <span class="d-stat__label">${s.label}</span>
      <span class="d-stat__delta ${s.flat ? 'flat' : ''}">${s.flat ? '' : '\u25B2 '}${s.delta}</span>
    </div>
  `).join('');

  const animateCount = (el) => {
    const target = parseInt(el.dataset.target, 10);
    const duration = 1200;
    const start = performance.now();
    const tick = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.floor(eased * target).toLocaleString('en-IN');
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };
  document.querySelectorAll('.d-stat__num').forEach(animateCount);

  /* ---------------------------------------------------------------------
     9. RECENTLY FILED PROBLEMS
  --------------------------------------------------------------------- */
  const problems = [
    { id: '1042', title: 'Drainage failure floods school access road every monsoon', loc: 'Ranchi', date: '12 Jul 2026', status: 'PROJECT ACTIVE', color: '#E8794A' },
    { id: '1108', title: 'Groundwater contamination near tannery cluster', loc: 'Dhanbad', date: '03 Aug 2026', status: 'OPEN FOR SOLUTIONS', color: '#4A90D9' },
    { id: '1156', title: 'No cold-storage access for tomato farmers', loc: 'Ranchi', date: '22 Jul 2026', status: 'VALIDATED', color: '#3AA76D' },
    { id: '1201', title: 'Primary health centre lacks a functioning ultrasound unit', loc: 'Bokaro', date: '29 Jul 2026', status: 'UNDER REVIEW', color: '#C25BA0' },
  ];

  document.getElementById('problemList').innerHTML = problems.map(p => `
    <div class="problem-item" tabindex="0">
      <span class="p-dot" style="background:${p.color}"></span>
      <div class="problem-item__main">
        <div><strong>#${p.id}</strong>${p.title}</div>
        <div class="problem-item__meta">${p.loc} &middot; ${p.date}</div>
      </div>
      <span class="status-pill">${p.status}</span>
    </div>
  `).join('');

  /* ---------------------------------------------------------------------
     10. TOP DOMAINS
  --------------------------------------------------------------------- */
  const domains = [
    { label: 'Water & Sanitation', pct: 20 },
    { label: 'Agriculture', pct: 20 },
    { label: 'Infrastructure', pct: 16 },
    { label: 'Healthcare', pct: 14 },
    { label: 'Energy', pct: 10 },
  ];

  const domainList = document.getElementById('domainList');
  domainList.innerHTML = domains.map(d => `
    <div class="domain-row">
      <div class="domain-row__top"><span>${d.label}</span><span>${d.pct}%</span></div>
      <div class="domain-bar"><div class="domain-bar__fill" data-pct="${d.pct}" style="width:0"></div></div>
    </div>
  `).join('');

  const domainObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.width = entry.target.dataset.pct + '%';
        domainObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.4 });
  document.querySelectorAll('.domain-bar__fill').forEach(el => domainObserver.observe(el));

  /* ---------------------------------------------------------------------
     11. PARTICIPATING ORGANIZATIONS
  --------------------------------------------------------------------- */
  const orgs = [
    { name: 'MMMUT', abbr: 'M', type: 'University', stat: '14 problems solved' },
    { name: 'NIT Jamshedpur', abbr: 'NJ', type: 'University', stat: '9 problems solved' },
    { name: 'Civica NGO', abbr: 'CN', type: 'NGO', stat: '22 field deployments' },
    { name: 'AgroLink Startup', abbr: 'AS', type: 'Startup', stat: '\u20B96L raised' },
  ];

  document.getElementById('orgGrid').innerHTML = orgs.map(o => `
    <article class="org-card">
      <div class="org-card__top">
        <span class="org-card__logo">${o.abbr}</span>
        <div><div class="org-card__name">${o.name}</div><div class="org-card__type">${o.type}</div></div>
      </div>
      <div class="org-card__stat">${o.stat}</div>
    </article>
  `).join('');

  /* ---------------------------------------------------------------------
     12. COMPACT LEADERBOARD (top 5, tabbed — mirrors landing page table)
  --------------------------------------------------------------------- */
  const lbData = {
    universities: {
      cols: ['Rank', 'University', 'Solved', 'Deployed', 'Score'],
      rows: [['01', 'IIT Delhi', 24, 18, 96], ['02', 'IIT Bombay', 21, 15, 93], ['03', 'IIT Madras', 19, 13, 88], ['04', 'IIT Kanpur', 17, 11, 84], ['05', 'BITS Pilani', 15, 10, 81]]
    },
    industry: {
      cols: ['Rank', 'Company', 'Collaborations', 'Problems Supported', 'Tech Contributions'],
      rows: [['01', 'Tata Elxsi', 9, 14, 6], ['02', 'Infosys Foundation', 8, 12, 5], ['03', 'Wipro Cares', 7, 10, 4], ['04', 'L&T Technology', 6, 9, 4], ['05', 'HCL Foundation', 6, 8, 3]]
    },
    startups: {
      cols: ['Rank', 'Startup', 'Solutions', 'People Impacted', 'Funding Raised'],
      rows: [['01', 'WasteSense', 5, '18,000+', '\u20B948L'], ['02', 'AquaTrack', 4, '14,500+', '\u20B936L'], ['03', 'AgriBridge', 4, '12,300+', '\u20B932L'], ['04', 'UrbanFlow', 3, '9,800+', '\u20B924L'], ['05', 'HealthLink', 3, '9,200+', '\u20B922L']]
    },
    contributors: {
      cols: ['Rank', 'Contributor', 'Problems Reviewed', 'Solutions Mentored', 'Impact Points'],
      rows: [['01', 'Dr. Anita Rao', 32, 11, 210], ['02', 'Vikram Nair', 27, 9, 188], ['03', 'Fatima Sheikh', 24, 8, 172], ['04', 'Rohan Das', 20, 7, 155], ['05', 'Meera Iyer', 18, 6, 140]]
    }
  };

  const dashLbTable = document.getElementById('dashLbTable');
  const renderDashTable = (key) => {
    const data = lbData[key];
    const head = `<thead><tr>${data.cols.map(c => `<th>${c}</th>`).join('')}</tr></thead>`;
    const body = `<tbody>${data.rows.map(row => `
      <tr>
        <td class="lb-rank ${row[0] === '01' ? 'top' : ''}">${row[0]}</td>
        <td class="lb-name">${row[1]}</td>
        ${row.slice(2).map(v => `<td>${v}</td>`).join('')}
      </tr>
    `).join('')}</tbody>`;
    dashLbTable.innerHTML = head + body;
  };

  document.querySelectorAll('.tabs .tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tabs .tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      renderDashTable(tab.dataset.tab);
    });
  });
  renderDashTable('universities');

});
