/* =========================================================================
   CIVICSOLVE — SCRIPT.JS
   All interactions are frontend-only. No backend / API calls.
   ========================================================================= */

document.addEventListener('DOMContentLoaded', () => {

  /* ---------------------------------------------------------------------
     1. STICKY NAVBAR SHADOW ON SCROLL
  --------------------------------------------------------------------- */
  const navbar = document.getElementById('navbar');
  const backToTop = document.getElementById('backToTop');

  const onScroll = () => {
    const scrolled = window.scrollY > 20;
    navbar.classList.toggle('scrolled', scrolled);
    backToTop.classList.toggle('show', window.scrollY > 600);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

  /* ---------------------------------------------------------------------
     2. DARK MODE TOGGLE (persists for this session only)
  --------------------------------------------------------------------- */
  const themeToggle = document.getElementById('themeToggle');
  const themeIcon = themeToggle.querySelector('i');

  const applyTheme = (dark) => {
    document.body.classList.toggle('dark', dark);
    themeIcon.className = dark ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
  };

  // Saved choice (shared with the dashboard) takes priority, otherwise fall
  // back to system preference on first visit.
  const savedTheme = localStorage.getItem('civicsolve-theme');
  applyTheme(savedTheme ? savedTheme === 'dark' : window.matchMedia('(prefers-color-scheme: dark)').matches);

  themeToggle.addEventListener('click', () => {
    const nowDark = !document.body.classList.contains('dark');
    applyTheme(nowDark);
    localStorage.setItem('civicsolve-theme', nowDark ? 'dark' : 'light');
  });

  /* ---------------------------------------------------------------------
     3. MOBILE NAV DRAWER
  --------------------------------------------------------------------- */
  const hamburger = document.getElementById('hamburger');
  const mobileDrawer = document.getElementById('mobileDrawer');

  hamburger.addEventListener('click', () => {
    const open = hamburger.classList.toggle('open');
    mobileDrawer.classList.toggle('open', open);
    hamburger.setAttribute('aria-expanded', open);
  });

  mobileDrawer.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      hamburger.classList.remove('open');
      mobileDrawer.classList.remove('open');
    });
  });

  /* ---------------------------------------------------------------------
     4. NAVBAR MEGA-OVERLAY (hover tooltip panel)
  --------------------------------------------------------------------- */
  const overlayContent = {
    impact: {
      title: 'IMPACT',
      desc: 'Track the real-world outcomes created through collaborative problem solving.',
      list: ['People benefited', 'Problems solved', 'Solutions deployed']
    },
    innovators: {
      title: 'INNOVATORS',
      desc: 'Discover students, startups and innovators building solutions.',
      list: ['Student teams', 'Startup builders', 'Independent researchers']
    },
    challenges: {
      title: 'CHALLENGES',
      desc: 'Explore real societal problems waiting for solutions.',
      list: ['Smart city issues', 'Health & sanitation', 'Rural infrastructure']
    },
    about: {
      title: 'ABOUT US',
      desc: 'Learn how CivicSolve connects society, academia and industry.',
      list: ['Our mission', 'How matching works', 'Governance & trust']
    },
    contact: {
      title: 'CONTACT US',
      desc: 'Connect with our team and collaborate with us.',
      list: ['General enquiries', 'Partnership requests', 'Media & press']
    }
  };

  const navOverlay = document.getElementById('navOverlay');
  const overlayEyebrow = document.getElementById('overlayEyebrow');
  const overlayDesc = document.getElementById('overlayDesc');
  const overlayList = document.getElementById('overlayList');
  const overlayItems = document.querySelectorAll('.has-overlay');
  let overlayTimer = null;

  const openOverlay = (key, li) => {
    const data = overlayContent[key];
    if (!data) return;
    overlayEyebrow.textContent = data.title;
    overlayDesc.textContent = data.desc;
    overlayList.innerHTML = data.list.map(item => `<li>${item}</li>`).join('');
    navOverlay.classList.add('open');
    overlayItems.forEach(el => el.classList.remove('overlay-active'));
    li.classList.add('overlay-active');
  };

  const closeOverlay = () => {
    navOverlay.classList.remove('open');
    overlayItems.forEach(el => el.classList.remove('overlay-active'));
  };

  overlayItems.forEach(li => {
    li.addEventListener('mouseenter', () => {
      clearTimeout(overlayTimer);
      openOverlay(li.dataset.overlay, li);
    });
    li.addEventListener('mouseleave', () => {
      overlayTimer = setTimeout(closeOverlay, 150);
    });
  });

  navOverlay.addEventListener('mouseenter', () => clearTimeout(overlayTimer));
  navOverlay.addEventListener('mouseleave', () => { overlayTimer = setTimeout(closeOverlay, 150); });

  /* ---------------------------------------------------------------------
     5. LOGIN ROUTING + MODALS
     This is a UI prototype: there is no real authentication. Any trigger
     carrying data-role (the three entry points — problem submitter,
     problem solver, industry/collaboration partner) navigates straight
     to the dashboard, passing the role as a query param so the dashboard
     — and a future real auth layer — can read it. Triggers with only
     data-modal (no role) still open the placeholder modal, in case a
     non-login "coming soon" moment is needed elsewhere later.
  --------------------------------------------------------------------- */
  const ROLE_MAP = { giver: 'submitter', solver: 'solver', industry: 'industry' };

  document.querySelectorAll('[data-modal]').forEach(trigger => {
    trigger.addEventListener('click', () => {
      if (trigger.dataset.role && ROLE_MAP[trigger.dataset.role]) {
        window.location.href = `dashboard.html?role=${ROLE_MAP[trigger.dataset.role]}`;
        return;
      }
      const modal = document.getElementById(trigger.dataset.modal);
      if (modal) modal.classList.add('open');
    });
  });

  document.querySelectorAll('[data-close-modal]').forEach(closer => {
    closer.addEventListener('click', () => {
      closer.closest('.modal-overlay').classList.remove('open');
    });
  });

  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) overlay.classList.remove('open');
    });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
    }
  });

  /* ---------------------------------------------------------------------
     6. PARTICIPATED INSTITUTIONS — expandable panel with dummy data
  --------------------------------------------------------------------- */
  const institutions = [
    { name: 'MMMUT', abbr: 'MM', solved: 14, deployed: 9, collabs: 4 },
    { name: 'IIT Bombay', abbr: 'IB', solved: 21, deployed: 15, collabs: 8 },
    { name: 'IIT Delhi', abbr: 'ID', solved: 24, deployed: 18, collabs: 9 },
    { name: 'IIT Madras', abbr: 'IM', solved: 19, deployed: 13, collabs: 6 },
    { name: 'IIT Kanpur', abbr: 'IK', solved: 17, deployed: 11, collabs: 5 },
    { name: 'NIT Trichy', abbr: 'NT', solved: 12, deployed: 8, collabs: 3 },
    { name: 'BITS Pilani', abbr: 'BP', solved: 15, deployed: 10, collabs: 5 },
  ];

  const institutionsGrid = document.getElementById('institutionsGrid');
  institutionsGrid.innerHTML = institutions.map(u => `
    <article class="inst-card">
      <div class="inst-card__top">
        <span class="inst-card__logo">${u.abbr}</span>
        <span class="inst-card__name">${u.name}</span>
      </div>
      <div class="inst-card__stats">
        <div><strong>${u.solved}</strong>Solved</div>
        <div><strong>${u.deployed}</strong>Deployed</div>
        <div><strong>${u.collabs}</strong>Collabs</div>
      </div>
    </article>
  `).join('');

  /* ---------------------------------------------------------------------
     7. ECOSYSTEM — expandable panel with dummy data
  --------------------------------------------------------------------- */
  const ecosystem = [
    { icon: 'fa-rocket', label: 'Startups', value: '12 active' },
    { icon: 'fa-lightbulb', label: 'Innovators', value: '84 registered' },
    { icon: 'fa-coins', label: 'Funding Partners', value: '\u20B942L committed' },
    { icon: 'fa-microchip', label: 'Technology Providers', value: '27 partners' },
  ];

  const ecosystemGrid = document.getElementById('ecosystemGrid');
  ecosystemGrid.innerHTML = ecosystem.map(e => `
    <article class="eco-card">
      <i class="fa-solid ${e.icon}"></i>
      <h4>${e.label}</h4>
      <strong>${e.value}</strong>
    </article>
  `).join('');

  /* ---------------------------------------------------------------------
     8. EXPANDABLE PANEL TOGGLES (institutions / ecosystem)
     Only one panel open at a time keeps the page tidy.
  --------------------------------------------------------------------- */
  const institutionsPanel = document.getElementById('institutionsPanel');
  const ecosystemPanel = document.getElementById('ecosystemPanel');
  const showInstitutionsBtn = document.getElementById('showInstitutionsBtn');
  const showEcosystemBtn = document.getElementById('showEcosystemBtn');

  const togglePanel = (panel, otherPanel, btn) => {
    const willOpen = !panel.classList.contains('open');
    otherPanel.classList.remove('open');
    panel.classList.toggle('open', willOpen);
    btn.querySelector('i').className = willOpen ? 'fa-solid fa-xmark' : btn.dataset.icon;
  };

  showInstitutionsBtn.dataset.icon = 'fa-solid fa-building-columns';
  showEcosystemBtn.dataset.icon = 'fa-solid fa-diagram-project';

  showInstitutionsBtn.addEventListener('click', () => {
    togglePanel(institutionsPanel, ecosystemPanel, showInstitutionsBtn);
    if (institutionsPanel.classList.contains('open')) {
      institutionsPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  });
  showEcosystemBtn.addEventListener('click', () => {
    togglePanel(ecosystemPanel, institutionsPanel, showEcosystemBtn);
    if (ecosystemPanel.classList.contains('open')) {
      ecosystemPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  });

  /* ---------------------------------------------------------------------
     9. LEADERBOARD TABS + DUMMY DATA TABLES
  --------------------------------------------------------------------- */
  const leaderboardData = {
    universities: {
      cols: ['Rank', 'University', 'Problems Solved', 'Solutions Deployed', 'Industry Collaborations', 'Impact Score'],
      rows: [
        ['01', 'IIT Delhi', 24, 18, 9, 96],
        ['02', 'IIT Bombay', 21, 15, 8, 93],
        ['03', 'IIT Madras', 19, 13, 6, 88],
        ['04', 'IIT Kanpur', 17, 11, 5, 84],
        ['05', 'BITS Pilani', 15, 10, 5, 81],
        ['06', 'NIT Trichy', 12, 8, 3, 76],
        ['07', 'MMMUT', 14, 9, 4, 74],
        ['08', 'IIT Roorkee', 13, 9, 4, 72],
        ['09', 'VIT Vellore', 11, 7, 3, 68],
        ['10', 'Jadavpur University', 10, 6, 2, 64],
      ]
    },
    industry: {
      cols: ['Rank', 'Company', 'Collaborations', 'Problems Supported', 'Technology Contributions'],
      rows: [
        ['01', 'Tata Elxsi', 9, 14, 6],
        ['02', 'Infosys Foundation', 8, 12, 5],
        ['03', 'Wipro Cares', 7, 10, 4],
        ['04', 'L&T Technology', 6, 9, 4],
        ['05', 'HCL Foundation', 6, 8, 3],
        ['06', 'TCS Digital Impact', 5, 8, 3],
        ['07', 'Mahindra Rise', 5, 7, 2],
        ['08', 'Cisco India', 4, 6, 3],
        ['09', 'Siemens India', 4, 5, 2],
        ['10', 'Bosch India', 3, 5, 2],
      ]
    },
    funding: {
      cols: ['Rank', 'Organization', 'Projects Funded', 'Amount Contributed', 'Impact'],
      rows: [
        ['01', 'Innovation Foundation', 8, '\u20B912,50,000', 'High'],
        ['02', 'Rural Impact Fund', 6, '\u20B99,40,000', 'High'],
        ['03', 'NextGen Ventures', 5, '\u20B97,80,000', 'Medium'],
        ['04', 'Sustain India Trust', 5, '\u20B96,60,000', 'Medium'],
        ['05', 'Civic Angels Network', 4, '\u20B95,20,000', 'Medium'],
        ['06', 'Bharat Grants', 4, '\u20B94,90,000', 'Medium'],
        ['07', 'Impact First Capital', 3, '\u20B93,80,000', 'Growing'],
        ['08', 'Grassroots Fund', 3, '\u20B93,20,000', 'Growing'],
        ['09', 'Seed for Change', 2, '\u20B92,60,000', 'Growing'],
        ['10', 'OpenAccess Trust', 2, '\u20B92,10,000', 'Growing'],
      ]
    },
    startups: {
      cols: ['Rank', 'Startup', 'Solutions', 'People Impacted', 'Funding Raised'],
      rows: [
        ['01', 'WasteSense', 5, '18,000+', '\u20B948L'],
        ['02', 'AquaTrack', 4, '14,500+', '\u20B936L'],
        ['03', 'AgriBridge', 4, '12,300+', '\u20B932L'],
        ['04', 'UrbanFlow', 3, '9,800+', '\u20B924L'],
        ['05', 'HealthLink', 3, '9,200+', '\u20B922L'],
        ['06', 'SolarSetu', 3, '7,600+', '\u20B920L'],
        ['07', 'SafeStreets', 2, '6,100+', '\u20B915L'],
        ['08', 'EduReach', 2, '5,400+', '\u20B912L'],
        ['09', 'GreenGrid', 2, '4,900+', '\u20B910L'],
        ['10', 'CivicAI', 1, '3,200+', '\u20B96L'],
      ]
    }
  };

  const lbTable = document.getElementById('lbTable');
  const tabs = document.querySelectorAll('.tab');

  const renderTable = (key) => {
    const data = leaderboardData[key];
    const head = `<thead><tr>${data.cols.map(c => `<th>${c}</th>`).join('')}</tr></thead>`;
    const body = `<tbody>${data.rows.map(row => `
      <tr>
        <td class="lb-rank ${row[0] === '01' ? 'top' : ''}">${row[0]}</td>
        <td class="lb-name">${row[1]}</td>
        ${row.slice(2).map(v => `<td>${v}</td>`).join('')}
      </tr>
    `).join('')}</tbody>`;
    lbTable.innerHTML = head + body;
  };

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');
      renderTable(tab.dataset.tab);
    });
  });

  renderTable('universities'); // initial render

  /* ---------------------------------------------------------------------
     10. LEADERBOARD REFRESH ANIMATION (frontend-only demonstration)
  --------------------------------------------------------------------- */
  const refreshBtn = document.getElementById('refreshBtn');
  const refreshToast = document.getElementById('refreshToast');
  let toastTimer = null;

  refreshBtn.addEventListener('click', () => {
    refreshBtn.classList.add('spinning');
    setTimeout(() => refreshBtn.classList.remove('spinning'), 650);

    refreshToast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => refreshToast.classList.remove('show'), 2200);
  });

  /* ---------------------------------------------------------------------
     11. ANIMATED STATISTICS (IntersectionObserver + count-up)
  --------------------------------------------------------------------- */
  const statNums = document.querySelectorAll('.stat__num');

  const animateCount = (el) => {
    const target = parseInt(el.dataset.target, 10);
    const prefix = el.dataset.prefix || '';
    const suffix = el.dataset.suffix || '';
    const duration = 1400;
    const start = performance.now();

    const tick = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
      const value = Math.floor(eased * target);
      el.textContent = `${prefix}${value.toLocaleString('en-IN')}${suffix}`;
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };

  const statObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCount(entry.target);
        statObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  statNums.forEach(el => statObserver.observe(el));

  /* ---------------------------------------------------------------------
     12. SCROLL REVEAL ANIMATIONS
  --------------------------------------------------------------------- */
  const revealEls = document.querySelectorAll('.reveal');
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in-view');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  revealEls.forEach(el => revealObserver.observe(el));

  /* ---------------------------------------------------------------------
     13. HERO NETWORK BACKGROUND (signature element)
     Draws a quiet field of connected dots behind the hero — a visual
     metaphor for scattered civic problems being linked to solvers.
  --------------------------------------------------------------------- */
  const heroNetwork = document.getElementById('heroNetwork');
  if (heroNetwork) {
    const svgNS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(svgNS, 'svg');
    svg.setAttribute('viewBox', '0 0 1000 700');
    svg.setAttribute('preserveAspectRatio', 'xMidYMid slice');
    svg.style.width = '100%';
    svg.style.height = '100%';

    const points = [];
    const cols = 10, rows = 7;
    for (let i = 0; i < cols; i++) {
      for (let j = 0; j < rows; j++) {
        points.push({
          x: (i / (cols - 1)) * 1000 + (Math.random() * 40 - 20),
          y: (j / (rows - 1)) * 700 + (Math.random() * 40 - 20)
        });
      }
    }

    // connect nearby points with faint lines
    points.forEach((p, idx) => {
      points.slice(idx + 1).forEach(q => {
        const dist = Math.hypot(p.x - q.x, p.y - q.y);
        if (dist < 130) {
          const line = document.createElementNS(svgNS, 'line');
          line.setAttribute('x1', p.x); line.setAttribute('y1', p.y);
          line.setAttribute('x2', q.x); line.setAttribute('y2', q.y);
          line.setAttribute('stroke', 'currentColor');
          line.setAttribute('stroke-width', '1');
          line.setAttribute('opacity', '0.06');
          svg.appendChild(line);
        }
      });
    });

    points.forEach((p, i) => {
      const dot = document.createElementNS(svgNS, 'circle');
      dot.setAttribute('cx', p.x); dot.setAttribute('cy', p.y);
      dot.setAttribute('r', i % 7 === 0 ? 3.5 : 2);
      dot.setAttribute('fill', i % 7 === 0 ? '#FFD400' : 'currentColor');
      dot.setAttribute('opacity', i % 7 === 0 ? '0.55' : '0.15');
      svg.appendChild(dot);
    });

    heroNetwork.style.color = 'var(--text)';
    heroNetwork.appendChild(svg);
  }

  /* ---------------------------------------------------------------------
     14. SMOOTH SCROLL FOR IN-PAGE ANCHORS (accounts for fixed navbar)
  --------------------------------------------------------------------- */
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
      const id = link.getAttribute('href');
      if (id.length > 1) {
        const target = document.querySelector(id);
        if (target) {
          e.preventDefault();
          const navH = document.getElementById('navbar').offsetHeight;
          const top = target.getBoundingClientRect().top + window.scrollY - navH + 1;
          window.scrollTo({ top, behavior: 'smooth' });
        }
      }
    });
  });

});
